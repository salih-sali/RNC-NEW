import React from 'react'
import { Link, useNavigate } from "react-router-dom";
import "./Search.css"
import { useState } from 'react'
import axios from "axios";

function Search() {
const [listOfUsers, setListOfUsers] = useState([]);
const [data4, setData4] = useState({
    title:""
})

const [error, setError] = useState("");

// const handleSub=(e)=>{
//     e.preventDefault()
//     console.log(search)
// }

const handleChange = ({ currentTarget: input }) => {
    setData4({ ...data4, [input.name]: input.value });
};

// const title="Mongto"  ###########can be used
const handleS = async (e) => {
    e.preventDefault()
    // try {

        axios.get("http://localhost:8080/api/searching").then((response) => {
            setListOfUsers(response.data);
            console.log(response.data)
          });}

 const handleSq= async (e) => {
            e.preventDefault()
             try {
        const url = "http://localhost:8080/api/searching/ser";
        //const { data: res } = await axios.post(url, {title : title})  ### must be post 
        axios.post(url, data4).then((response) => {
            setListOfUsers(response.data);
            console.log(response.data)
          })
        //navigate("/sign-in")
        //console.log(res.message)
    
    } catch (error) {
        if (
            error.response &&
            error.response.status >= 400 &&
            error.response.status <= 500
        ) {
            setError(error.response.data.message)
        }
    }}
    

// const handleS = async (e) => {
//     e.preventDefault();
//     try {
//         const url = "http://localhost:8080/api/searching";
//         const { data: res } = await axios.push(url, search);

//   // fetch("http://localhost:8080/api/auth")
//   // .then(response=>response.json())
//   console.log(data)
//         //localStorage.setItem("token", res.data);
//         window.location = "/home";
//     } catch (error) {
//         if (
//             error.response &&
//             error.response.status >= 400 &&
//             error.response.status <= 500
//         ) {
//             setError(error.response.data.message);
//         }
//     }
// }
    return (
<div className='search'>
<h1>&nbsp;&nbsp;&nbsp;searching and sorting</h1>
<form>
<label>
    &nbsp;&nbsp; view all list of publications
    </label>
    <button onClick={handleS}>View all</button>

            <br/>
<br/>
<label>
     Enter field to be search
    </label>&nbsp;&nbsp;
    <input style={{ width:"500px" }}
              className="input"
              type="text"
              id="fname"
              //name="name"
              placeholder="search by title"
              name="title"
           
            onChange={handleChange}
            value={data4.title}
            
            
              required
            />&nbsp;&nbsp;
            
    <button onClick={handleSq}>search</button>
    
</form>
<br/>
<br/>
<br/>
{listOfUsers.map((user) => {
          return (
            <div><br/>
                
                &nbsp; &nbsp;
                <h6>Name: {user.title}&nbsp;&nbsp;
             author: {user.author}&nbsp;&nbsp;
              year: {user.year}</h6>
            
            </div>
          );
        })}
</div>
    )
    }

    
    export default Search