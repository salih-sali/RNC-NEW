import React from 'react'
import './Footer.css'



function Footer() {
  return (
   
    <div>
        <footer className='ftr'>
      <div class="container ">
       
        
      </div>
    </footer>
    </div>

    

  )
}

export default Footer