import React from 'react'
import './Banner.css'

function Banner() {
  return (
    <div className='banner'>
      
       <div className="fade_bottom">
        
       </div>

    </div>
  )
}

export default Banner