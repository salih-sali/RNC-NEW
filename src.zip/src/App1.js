import React from 'react'
import App from './App'
import Form1 from './forms/Form1'
import NavBar from './components/Navbar/Navbar'
import Banner from './components/Banner/Banner'
import Des from './components/Description/Description'
import Foot from './components/Footer/Footer'
import { BrowserRouter as Router} from 'react-router-dom'

import Lk from '../src/components/page/Home'

function App1() {

  return (
    <div>  
      
      <NavBar />
      
    </div>
  )
}

export default App1