import React from 'react'
import './home.css'
import { Link, useNavigate } from "react-router-dom";
import AddD from '../Navbar/addD/AddD'


function Home() {


  return (
    <div className='homeq'>
      <h1>jgcdsgyugyugefygs</h1>
      
         
    </div>
  )
}

export default Home