import React from 'react'
import './Banner.css'

function Banner() {
  return (
    <div className='banner'>
        <div className='content'>
            <p className='Intro'> The R & C cell is pursued with the following objectives:<br/>

1.To promote undergraduate research <br/>

2.To establish the research culture among faculty and there by design and develop new technologies in their respective areas.
</p>
        </div>
       <div className="fade_bottom">
        
       </div>

    </div>
  )
}

export default Banner