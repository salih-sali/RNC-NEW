import React from 'react'
import './Description.css'


function Description() {
  return (
    <div className='Desc'>
        
    </div>
  )
}

export default Description