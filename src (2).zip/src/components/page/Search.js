import React from 'react'
import { Link, useNavigate } from "react-router-dom";

import { useState } from 'react'

function Search() {
// function handleClick(){
    
//     var val = document.getElementById('fname').value
//     console.log(val)
// }

const [search,setSearch] = useState('')

const handleS=(e)=>{
    e.preventDefault()
    console.log(search)
}

    return (
<div>
<h1>searching and sorting</h1>
<form>
    <label>
        enter field to be search
    </label>
    <input style={{ width:"500px" }}
              className="input"
              type="text"
              id="fname"
              //name="name"
              placeholder="Enter"
              name="fileds"
              
            value={search}
            onChange={(e)=>setSearch(e.target.value)}
              required
            />
    <button onClick={handleS}>search</button>
</form>
</div>
    )
    }

    
    export default Search